class Inscripcion {
    constructor(nombre, carnet, carrera, materias) {
        this.nombre = nombre;
        this.carnet = carnet;
        this.carrera = carrera;
        this.materias = materias;
        this.laboratorio = 0;
        this.matricula = 200;
        this.otrosPagos = 50;
        this.total = 0;
    }
    
    calcularTotal() {
        this.materias.forEach(materia => {
            if (materia.includes('Lab')) {
                this.laboratorio += 50;
            }
        });
        this.total = this.laboratorio + this.matricula + this.otrosPagos;
    }
    
    mostrarInscripcion() {
        alert(`Nombre: ${this.nombre}\nCarné: ${this.carnet}\nCarrera: ${this.carrera}\nMaterias: ${this.materias.join(', ')}\nTotal: $${this.total}`);
    }
}

const form = document.getElementById('inscripcionForm');
form.addEventListener('submit', e => {
    e.preventDefault();
    const nombre = form.elements.nombre.value;
    const carnet = form.elements.carnet.value;
    const carrera = form.elements.carrera.value;
    const materias = Array.from(form.elements.materias).map(input => input.value);
    const inscripcion = new Inscripcion(nombre, carnet, carrera, materias);
    inscripcion.calcularTotal();
    inscripcion.mostrarInscripcion();
    form.reset();
});

document.querySelector('.addMateria').addEventListener('click', () => {
    const newMateriaInput = document.createElement('input');
    newMateriaInput.type = 'text';
    newMateriaInput.className = 'materia';
    newMateriaInput.name = 'materias[]';
    newMateriaInput.required = true;
    newMateriaInput.pattern = "[A-Za-z\s]+";
    document.getElementById('materiasContainer').appendChild(newMateriaInput);
});