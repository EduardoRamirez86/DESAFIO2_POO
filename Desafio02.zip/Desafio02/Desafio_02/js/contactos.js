const form = document.getElementById('contactoForm');
form.addEventListener('submit', e => {
    e.preventDefault();
    const nombre = form.elements.nombre.value;
    const email = form.elements.email.value;
    const mensaje = form.elements.mensaje.value;
    alert(`Nombre: ${nombre}\nCorreo: ${email}\nMensaje: ${mensaje}`);
    form.reset();
});