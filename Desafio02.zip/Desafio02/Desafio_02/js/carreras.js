document.querySelectorAll('.carrera').forEach(carrera => {
    carrera.addEventListener('click', () => {
        const carreraNombre = carrera.querySelector('h2').innerText;
        const carreraImagen = carrera.querySelector('img').src;
        const carreraDescripcion = obtenerDescripcion(carrera.dataset.carrera);

        document.getElementById('modal-title').innerText = carreraNombre;
        document.getElementById('modal-image').src = carreraImagen;
        document.getElementById('modal-description').innerText = carreraDescripcion;

        document.getElementById('modal').style.display = 'block';
    });
});

document.querySelector('.close').addEventListener('click', () => {
    document.getElementById('modal').style.display = 'none';
});

window.onclick = function(event) {
    if (event.target == document.getElementById('modal')) {
        document.getElementById('modal').style.display = 'none';
    }
};

function obtenerDescripcion(carrera) {
    const descripciones = {
        computacion: "",
        industrial: "",
        telecomunicaciones: "",
        diseno: "",
        tecnico_computacion: "",
        control_calidad: ""
    };
    return descripciones[carrera] || "";
}